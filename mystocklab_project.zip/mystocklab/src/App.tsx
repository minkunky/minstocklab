import { TrendingUp } from 'lucide-react'
import './App.css'

function App() {
  return (
    <div className="app">
      <h1>
        <TrendingUp size={32} />
        MyStockLab
      </h1>
      <p>주식 포트폴리오 앱에 오신 것을 환영합니다!</p>
    </div>
  )
}

export default App
